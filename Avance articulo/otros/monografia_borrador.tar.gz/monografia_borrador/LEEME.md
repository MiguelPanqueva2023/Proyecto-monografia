# Estructura de Monografía - Borrador Autodescriptiva

## Descripción
Esta carpeta contiene una estructura vacía "autodescriptiva" para monografías de grado. Cada archivo contiene guías detalladas sobre qué contenido debe incluirse en cada sección.

## Estructura de Archivos

```
monografia_borrador/
├── main.tex                    # Plantilla principal
├── referencias.bib              # Archivo de referencias BibTeX
├── capitulos/
│   ├── capitulo1.tex          # Introducción
│   ├── capitulo2.tex          # Marco Teórico
│   ├── capitulo3.tex          # Metodología
│   ├── capitulo4.tex          # Desarrollo/Implementación
│   ├── capitulo5.tex          # Resultados
│   ├── capitulo6.tex          # Análisis y Discusión
│   └── capitulo7.tex         # Conclusiones y Recomendaciones
├── recursos/
│   └── (imágenes y recursos)
└── anexos/
    └── anexos.tex             # Anexos
```

## Cómo Usar Esta Estructura

### 1. Completar main.tex
- Editar información del título, autores y director
- Ajustar preámbulo según necesidades específicas

### 2. Completar Capítulos
Cada archivo de capítulo incluye:
- **Encabezado** con descripción del propósito del capítulo
- **Secciones sugeridas** con contenido placeholder
- **Comentarios** explicando qué incluir en cada parte
- **Ejemplos de estructura** cuando son útiles

### 3. Compilar
```bash
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

## Descripción de Capítulos

| Capítulo | Propósito | Secciones Clave |
|----------|-----------|-----------------|
| 1. Introducción | Contextualizar el problema | Antecedentes, Problema, Objetivos, Justificación, Alcance |
| 2. Marco Teórico | Fundamentar conceptualmente | Fundamentos, Estado del Arte, Brechas |
| 3. Metodología | Describir el diseño | Diseño, Población, Hipótesis, Variables, Instrumentos |
| 4. Desarrollo | Documentar implementación | Arquitectura, Herramientas, Detalles técnicos, Pipeline |
| 5. Resultados | Presentar datos (objetivo) | Métricas, Tablas, Figuras, Análisis estadístico |
| 6. Análisis | Interpretar resultados | Comparación con literatura, Implicaciones, Limitaciones |
| 7. Conclusiones | Sintetizar hallazgos | Cumplimiento de objetivos, Contribuciones, Recomendaciones |

## Recomendaciones

1. **Comenzar por el Capítulo 1** (más straightforward)
2. **Escribir el Marco Teórico** en paralelo con la revisión de literatura
3. **La Metodología** debe escribirse antes de ejecutar experimentos
4. **Resultados** se completa con los datos obtenidos
5. **Análisis** requiere haber terminado Resultados
6. **Conclusiones** es el último capítulo en escribirse

## Personalización

- Ajustar los paquetes de LaTeX según necesidades
- Agregar o eliminar secciones según el tipo de investigación
- Modificar el formato de tablas y figuras según el estilo requerido
